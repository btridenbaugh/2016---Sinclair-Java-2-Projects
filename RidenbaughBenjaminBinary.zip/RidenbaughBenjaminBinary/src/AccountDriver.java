import java.util.Scanner;

public class AccountDriver{
	static Facebook ab;

	public static int getMenuOption() {

		// Facebook ab = new Facebook();

		System.out
				.print("\nMenu \n1. List Users \n2. Add a Users \n3. Delete a User"
						+ " \n4. Get password hint\n5. Quit");
		System.out.print("\nWhat would you like to do: ");
		@SuppressWarnings("resource")
		Scanner input1 = new Scanner(System.in);
		int num4 = input1.nextInt();

		while ((num4 < 1 || num4 > 5) && num4 != 5)
		{
			System.out.println("Please the enter the options 1,2,3,4,5: ");
			num4 = input1.nextInt();
		}
		return num4;
	}

	public static void main(String[] args) {
		
		@SuppressWarnings("resource")
		Scanner input = new Scanner(System.in);
		// Get from user input if this is first attempt to use this application
		
		System.out.println("Is it you first attempt (y/n): ");
		String ans = input.next();
		try {
		if(ans .toLowerCase().equals("y"))
		{

		

			ab = new Facebook(
					"users.txt",
					true);
		
		}
		else{
			
				ab = new Facebook(
						"users.txt",
						false);
		}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
		while (true) {

			int menu = getMenuOption();// menu
			
			String aName, aPassword;
			String aPasswordHint;

			

			// new user account
			switch (menu) {
			case 1:
				// list of users

				if (ab.users.isEmpty()) {// checks the list
					System.out.println("No User Have Been Entered Yet");
					System.out.print(System.getProperty("line.separator"));
				} 
				
				System.out.println(ab.users);

				break;

			case 2: //add
				FacebookUser fUser;
				while (true) {
					System.out.println("Please enter an Username: ");

					aName = input.next();
					if (ab.findUser(aName)==-1)
						break;
				}

				System.out.println("Enter a password: ");
				aPassword = input.next();

				fUser = new FacebookUser(aName, aPassword);

				System.out.println("Enter a password hint: ");// enter hint
				aPasswordHint = input.next();
				fUser.setPasswordHint(aPasswordHint);

				ab.addUsers(fUser);
				break;

			case 3: //delete
				
				

				System.out.println("Please enter an Username: ");
				aName = input.next();
				ab.deleteUser(aName);
				break;
			case 4: // show password hint
				
					System.out.println("Please enter an Username: ");

					aName = input.next();
					ab.getPasswordHint(aName);
				
			break;
			case 5:
				System.out.println("Goodbye");
				try {
					ab.serialize();
				} catch (Exception e) {
					e.printStackTrace();
				}
				System.exit(0);
				

			}
		}
	}
}
