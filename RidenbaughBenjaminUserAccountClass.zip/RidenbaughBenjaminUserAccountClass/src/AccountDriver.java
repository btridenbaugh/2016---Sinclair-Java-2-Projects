public class AccountDriver {


	
	

	public static void main(String [] args){
		
		UserAccount account1 = new UserAccount("benj", "fght");// new account object
		UserAccount account2 = new UserAccount("riden", "rtyy");// second account object
		
		System.out.println("account1:\n" +account1);
		System.out.println("account2:\n" +account2);
		
		if(account1.checkPassword("fght"))System.out.println("Password worked");// system print out password worked
		if(account2.checkPassword("xtyy"))System.out.println("Password failed");
		
		account1.deactivateAccount();
		
		System.out.println(account1.toString());
		
		if(account1.equals(account2))System.out.println("failed as it should");
		if(account1.equals(account1))System.out.println("passed as it should");
	}
}