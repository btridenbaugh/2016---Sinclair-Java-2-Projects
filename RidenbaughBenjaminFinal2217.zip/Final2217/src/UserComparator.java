import java.util.Comparator;

public class UserComparator implements Comparator<TwitterUser> {

	@Override
	public int compare(TwitterUser o1, TwitterUser o2) {
		int res = 0;

		// 3. If two users have the same number of followers and are following
		// the same number of people, sort by user id (smallest to largest)
		if ((o1.getFollowers().size() == o2.getFollowers().size())
				&& (o1.getFollowing().size() == o2.getFollowing().size()))
			res = (o1.getID() < o2.getID() ? 1 : 0);

		// 2. If two users have the same number of followers, sort by the number
		// of people that user is following (largest to smallest)
		if (o1.getFollowers().size() == o2.getFollowers().size())
			res = o1.getFollowing().size() > o2.getFollowing().size() ? 1 : 0;

		// 1. Number of followers (largest to smallest)
		if (o1.getFollowers().size() > o2.getFollowers().size())
			res = 1;

		return res;
	}

}
