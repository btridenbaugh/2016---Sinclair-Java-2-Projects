import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Stack;

//MAKE SURE TO PUT IN FILE LOCATION BEFORE RUNNING

public class Driver {

	static ArrayList<TwitterUser> users = new ArrayList<TwitterUser>();
	static Scanner input = new Scanner(System.in);

	public static void main(String[] args) {
		String filename;
		String line;
		int userID, followID, depth;
		TwitterUser userObj, followObj, cloneTestObj;

		 filename = "C://Users/coolc/Downloads/social_network.edgelist/social_network.edgelist";

		long startTime = System.currentTimeMillis();
		long endTime;

		try {
			BufferedReader file = new BufferedReader(new FileReader(filename));
			System.out.println("\tReading data from the file...");

			Stack<Integer[]> followers = new Stack<Integer[]>();

			HashSet<TwitterUser> hashSet = new HashSet<TwitterUser>(1000000);

			while ((line = file.readLine()) != null && !line.isEmpty()) {
				String[] ids = line.split(" ");
				userID = Integer.parseInt(ids[0]);
				followID = Integer.parseInt(ids[1]);

				hashSet.add(new TwitterUser(userID));
				hashSet.add(new TwitterUser(followID));

				// Followers begin
				followers.push(new Integer[] { userID, followID });
				// Followers end
			}
			endTime = System.currentTimeMillis();
			System.out.println("\tFinished adding " + hashSet.size()
					+ " users in " + (int) ((endTime - startTime) / 1000)
					+ " seconds.");
			file.close();

			// Map all TwitterUsers to their ID in HashMap
			HashMap<Integer, TwitterUser> hashMap = new HashMap<Integer, TwitterUser>();
			for (TwitterUser t : hashSet) {
				hashMap.put(t.getID(), t);
			}

			file = new BufferedReader(new FileReader(filename));

			startTime = System.currentTimeMillis();
			int counter = 0;
			System.out.println("\n\tFriending...");
			while ((line = file.readLine()) != null && !line.isEmpty()) {
				String[] ids = line.split(" ");
				userID = Integer.parseInt(ids[0]);
				followID = Integer.parseInt(ids[1]);

				userObj = hashMap.get(userID);
				followObj = hashMap.get(followID);

				userObj.followUser(followObj);
				counter++;
			}
			file.close();
			endTime = System.currentTimeMillis();
			System.out.println("\tFinished all " + counter
					+ " friending operations in "
					+ (int) ((endTime - startTime) / 1000) + " seconds.");

			// Transfer HashMap values to ArrayList of TwitterUsers
			for (TwitterUser t : hashMap.values()) {
				users.add(t);
			}

			// Followers begin
			
			mapFollowers(followers);

			// Followers end

		} 
		catch (IOException i) {
			System.out.println("\tIOException: ");
			i.printStackTrace();
		}

		//Get Neighbourhood Test
		
		System.out
				.print("\nTest for the getNeighborhood(user, depth) function:"
						+ "\n\tEnter the user you would like to test: ");
		userID = input.nextInt();
		userObj = getUser(userID);
		System.out
				.print("\tEnter the depth you would like to go to in your neighborhood: ");
		depth = input.nextInt();
		while (depth < 0 || (depth > userObj.getFollowing().size())) {
			System.out
					.print("\tPlease enter a positive number less than or equal to "
							+ userObj.getFollowing().size() + ": ");
		depth = input.nextInt();
		
		}
		userObj.getNeighborhood(userObj, depth);

		// Clone method test
	
		final int TEST_USER = 0;
		System.out.println("\nTesting the clone() function for deep copy:");
		userObj = getUser(TEST_USER);
		System.out.println("\tCloning User " + userObj + ".");
		cloneTestObj = (TwitterUser) userObj.clone();
		System.out.println("\tUser " + userObj + " successfully cloned.");
		System.out.println("\tUser 0's following list: "
				+ userObj.getFollowing() + "\n\tClone's following list: "
				+ cloneTestObj.getFollowing());
		System.out.print("\tClearing the clone's following list.");
		cloneTestObj.clearFollowing();
		System.out.println("\n\tUser 0's following list: "
				+ userObj.getFollowing() + "\n\tClone's following list: "
				+ cloneTestObj.getFollowing());

		// Followers test begin
		System.out.print("\nTest for the followers function:"
				+ "\n\tEnter the user you would like see list of followers: ");
		userID = input.nextInt();

		test_getFollowing(getUser(userID));

		// Followers test end

		// Popularity test begin
		System.out
				.print("\nTest for the followers getByPopularity function:"
						+ "\n\tEnter the user index for which you would like to see popularity: ");
		int idx = input.nextInt();

		TwitterUser u = getByPopularity(idx);
		System.out.print("\nThe  " + idx + "th popular user is :" + u.getID()
				+ " number of followers  " + u.getFollowers().size());

		// Popularity test end

		System.out.println("\n\nExiting.");
	}

	public static TwitterUser getUser(int userID) {
		TwitterUser temp;
		temp = new TwitterUser(userID);
		while (!users.contains(temp)) {
			System.out.print("\tInvalid user ID.  Enter a valid user id: ");
			userID = input.nextInt();
			temp.setUserID(userID);
		}
		return users.get(users.indexOf(temp));
	}

	// Followers && Popularity begin


	private static void mapFollowers(Stack<Integer[]> followers) {

		System.out.println("\nMapping Followers, Please Wait..\n\n");
		
		while (!followers.isEmpty()) {
			Integer[] anEntry = followers.pop();
			Integer aUserId = anEntry[1];
			List<Integer> f = findFollowersForUser(
					(Stack<Integer[]>) followers.clone(), aUserId);
			System.out.println("User " + aUserId + " has " + f.size()
					+ " followers.");
			TwitterUser aUser = getUser(aUserId);
			aUser.setFollowers(f);
		}
	
		
	}


	private static List<Integer> findFollowersForUser(Stack<Integer[]> sList,
			Integer id) {

		List<Integer> f = new ArrayList<Integer>();

		while (!sList.isEmpty()) {
			Integer[] ids = sList.pop();
			if (id - ids[1] == 0) {
				f.add(ids[0]);
		}
		}
		return f;
	}

	public static void test_getFollowing(TwitterUser user) {
		Collection<TwitterUser> followerUsers = user.getFollowing(user);
		List<Integer> followers = new ArrayList<Integer>();
		for (TwitterUser aUser : followerUsers) {
			followers.add(aUser.getID());
		}
		System.out.println("User " + user.getID() + " has " + followers
				+ " followers. ");
	}

	private static TwitterUser getByPopularity(int idx) {
		Collections.sort(users, new UserComparator());
		return users.get(idx);
	}

	// Followers && Popularity end

}
