import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class TwitterUser implements Comparable<TwitterUser>, Cloneable {

	private int id;

	private ArrayList<TwitterUser> following = new ArrayList<TwitterUser>();

	public TwitterUser() {

	}

	public TwitterUser(int userID) {
		id = userID;
	}

	public void getNeighborhood(TwitterUser user, int depth) {
		System.out.println("\tUser " + user + ", Friends: "
				+ user.getFollowing());
		if (depth <= 0) {
			// do nothing
		} else {
			for (int i = 0; i < depth; i++) {
				TwitterUser temp = following.get(i);
				getNeighborhood(temp, 0);
			}
		}

	}

	public void followUser(TwitterUser user) {
		if (!following.contains(user)) {
			following.add(user);
		}
	}

	public void clearFollowing() {
		following.clear();
	}

	public ArrayList<TwitterUser> getFollowing() {
		ArrayList<TwitterUser> copy = new ArrayList<TwitterUser>();
		for (TwitterUser t : following) {
			copy.add(t);
		}
		return copy;
	}

	public int getID() {
		return id;
	}

	public void setUserID(int newId) {
		id = newId;
	}

	@Override
	public int compareTo(TwitterUser t) {
		if (id > t.getID()) {
			return 1;
		} else if (id < t.getID()) {
			return -1;
		} else {
			return 0;
		}
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + id;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TwitterUser other = (TwitterUser) obj;
		if (id != other.id)
			return false;
		return true;
	}

	public Object clone() {
		try {
			TwitterUser clonedUser = (TwitterUser) super.clone();
			clonedUser.following = (ArrayList<TwitterUser>) following.clone();
			return clonedUser;
		} catch (CloneNotSupportedException e) {
			return null;
		}
	}

	public String toString() {
		return Integer.toString(id);
	}

	// Followers begin

	 
	 // return a collection of the people who are following the user
	 

	public Collection<TwitterUser> getFollowing(TwitterUser user) {
		Collection<TwitterUser> tUser = new ArrayList<TwitterUser>();
		if (user.getID() == 415) {
			System.out.print("\nuser id: " + user.getID());

		}
		for (Integer t : user.getFollowers()) {
			tUser.add(new TwitterUser(t));
		}
		return tUser;

	}

	private List<Integer> followers = new ArrayList<>();

	public void setFollowers(List<Integer> f) {
		for (Integer i : f) {
			if (!followers.contains(i))
				followers.add(i);
		}
	}

	public List<Integer> getFollowers() {
		return followers;
	}

	// Followers end
}
