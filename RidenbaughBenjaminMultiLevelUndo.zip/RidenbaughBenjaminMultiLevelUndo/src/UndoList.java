public class UndoList {
	public FacebookUser user1;
	public FacebookUser user2;
	public int undoAction = 0;// undoaction 1 = adduser, undoaction2 =7
								// removefriend undoaction 3= like
	public String undoLikes;

	UndoList(FacebookUser usr1, FacebookUser usr2, int act, String like) {
		user1 = usr1;
		user2 = usr2;
		undoAction = act;
		undoLikes = like;
	}

}
