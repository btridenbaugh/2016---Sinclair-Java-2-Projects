import java.util.Comparator;



public class FriendListSize implements Comparator<FacebookUser> {
 
    @Override
    public int compare(FacebookUser FUser1, FacebookUser FUser2) {
    	return FUser1.friends.size() - FUser2.friends.size();
    }
}

