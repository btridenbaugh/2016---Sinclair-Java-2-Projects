import java.io.*;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;

import javax.swing.JOptionPane;

public class FacebookUser extends UserAccount implements Serializable,
		Comparable<FacebookUser> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static Scanner input = new Scanner(System.in);
	
	int UndoAction =0;
	FacebookUser undoFriend;
	
	String passwordHint;
	ArrayList<FacebookUser> friends;
	HashSet<String> likes = new HashSet<String>();	
	
	public FacebookUser(String username, String password) {
		super(username, password);
		friends = new ArrayList<FacebookUser>();	
	}
	
	void setPasswordHint(String hint) {
		passwordHint = hint; // hint
	};


	// adding a new friend
	// add the FacebookUser
	// method is add user as friend when not already to a friend
	// it use findFriend that returns -1 if not a friend
	// only the it inserts the object as friend
	// otherwise it emits a message
	public void addFriend(FacebookUser newFriend) {
		int i = findFriend(newFriend.username);
		if (i == -1){
			friends.add(newFriend);
			
		}
		else
			System.out.println(newFriend.username + " is already a friend");

	}

	// defriending a friend
	public void deFriend(FacebookUser formerFriend) {
		int i = findFriend(formerFriend.username);
		if (i == -1)
		{
			System.out.println(formerFriend.username + " is not found");
//		return;
		}
		else
			{friends.remove(i);
			}

	}
	//EXPLAINATION: We are supposed to use the SET dataStructure because we are not allowing duplicates
		//It uses the equals method to make sure that two objects are not Identical
	
	

	// displays users that are friends of friends

	@SuppressWarnings("unchecked")
	public HashSet<FacebookUser> getRecommendation(HashSet<FacebookUser> fList) {
		//fList is null First time
		// not null when recursion; fList is set that has to be excluded from set of friends during recursion
		HashSet<FacebookUser> gList = new HashSet<FacebookUser>(friends);
		//Case Recursion: Returns all Friends except those in fList
		// for recursion Friend of Friends not required since we stop when there is no more possible friends limit checkis done 
		if(fList != null){		
			gList.removeAll(fList); 
			return gList;
			
		}
		// case not recursion
		
		
		if (gList.isEmpty())
			return gList;// no recommendation
		// second
		
		HashSet<FacebookUser> g = new HashSet<FacebookUser>();

		for (FacebookUser f : gList) g.addAll(f.friends);
		gList.add(this);
		
		g.removeAll(gList);
		
		if (g.isEmpty())
			return g;
		// now we have set of friends of friends
				// but we don't know if we have all possible new friends
				// so we have to go over this list again and again till the size does
				// not get changed
				// h grows while we iterate on g
		// Third - Friends of Friends union to any level of Recursive depth -
		// this needs an extra iteration recognize the end that limit is reached
		// there shall not be anymore possible friends
		int prev = g.size();
		HashSet<FacebookUser> h = (HashSet<FacebookUser>) g.clone();
		
		while (true) {
			
		//gList is set of friends and user the Set returned after recursion must not include gList set
			for (FacebookUser f : g){
				//System.out.println("recursing"+f);
				h.addAll(f.getRecommendation(gList));
			}
			h.removeAll(gList); // ist level friend must always be removed
			if (prev < h.size()) {

				prev = h.size();
				g = (HashSet<FacebookUser>) h.clone();
			} else 
				return g; // recommendation
		}
	}
		
	// findFriend that locates a friend
	// this used to add a fiend when that friend is not already a friend
	// this used for defriend if it is a friend
	// i represents an index that points to name

	public int findFriend(String name) {
		if (friends.isEmpty())
			return -1;// s
		for (int i = 0; i < friends.size(); i++) {
			if (friends.get(i).username.equals(name))
				return i;
		}
		return -1;

	}

	// Recursively getting friends recommendations from friends list
	// list of usernames currently not on friends list and available number of
	// facebook users
	// getting friends' friends from their friend's list and not the same
	// username that user has


	ArrayList<FacebookUser> getFriends() {

		return friends;
	};

	public void getPasswordHelp() {
		JOptionPane.showMessageDialog(null, passwordHint);

	};

	public String getUsername() {
		return username;
	}

	public String getPassword() {
		return password;
	}

	@Override
	public int compareTo(FacebookUser o) {
		return username.toString().toLowerCase()
				.compareTo(o.username.toLowerCase());// case ignore

	}

}
