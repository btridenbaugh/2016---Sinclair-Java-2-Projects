import java.io.IOException;
import java.lang.*;
import java.util.*;

public class TestDriver {
	public static int getMenuOption() {



		System.out.print("\nMenu \n1. Insertion Sort String"
				+ "\n2. Integer" + "\n3. FacebookUsers "
				+"\n4. Quit ");

		System.out.print("\nWhat would you like to do: ");
		@SuppressWarnings("resource")
		Scanner input1 = new Scanner(System.in);
		int num4 = input1.nextInt();

		while ((num4 < 1 || num4 > 4) && num4 != 4)// added this to prompt the
													// inputs to user
		{
			System.out
					.println("Please the enter the options from above menu: ");
			num4 = input1.nextInt();
		}
		return num4;
	}

	public static void main(String[] args) throws IOException {
		InsertionSort ab = new InsertionSort();
		QuickSort bc = new QuickSort();
		QuickSortS cd = new QuickSortS();
		QuickSort de = new QuickSort();

		while (true) {

			int menu = getMenuOption();// menu

			// new user account
			switch (menu) {
			case 1: 
				System.out.println("\n Sorting test: String");

				String[] StringArray = { "E", "D", "C", "B", "A" };
				System.out.print("Integer: ");
				for(int i =0; i<StringArray.length; i++)
					System.out.print(StringArray[i] +" ");
				System.out.println();


				
				System.out.println("After Sorted"+"\n");
				InsertionSort.Sort(StringArray);
				
				Random rnd = new Random();
			    for (int i = StringArray.length - 1; i > 0; i--)
			    {
			      int index = rnd.nextInt(i + 1);
			      // Simple swap
			      String a = StringArray[index];
			      StringArray[index] = StringArray[i];
			      StringArray[i] = a;
			    

			}
				System.out.println("=======================");
				System.out.print("String: ");
				for(int i =0; i<StringArray.length; i++)
					System.out.print(StringArray[i] +" ");
				System.out.println();
				System.out.println("\n");
				
			;
			System.out.println();
			bc.quickSort(StringArray);
			System.out.println("Sorted String: ");
			for(int i =0; i<StringArray.length; i++)
				System.out.println(StringArray[i]);
			
				
				break;

			
			case 2: 
				System.out.println("\n Sorting test: Integer");

				Integer[] numbers = { 50, 0, 10, 15, 60, 33, 25 };

				System.out.println(numbers);
				System.out.println("After Sorted");
				InsertionSort.Sort(numbers);
				
				Random rnd1 = new Random();
			    for (int i = numbers.length - 1; i > 0; i--)
			    {
			      int index = rnd1.nextInt(i + 1);
			      // Simple swap
			      int a = numbers[index];
			      numbers[index] = numbers[i];
			      numbers[i] = a;
			    

			}


				System.out.print("Integer: ");
				for(int i =0; i<numbers.length; i++)
					System.out.print(numbers[i] +" ");
				System.out.println();
				bc.quickSort(numbers);
				System.out.println("Sorted Integer: ");
				for(int i =0; i<numbers.length; i++)
					System.out.println(numbers[i]);
			    break;
			
			case 3: 
				// FacebookUSers
				FacebookUser account1 = new FacebookUser("soham", "fight");// new
																			// account
																			// object
				FacebookUser account2 = new FacebookUser("Ellen", "fight");// second
																			// account
																			// object
				FacebookUser account3 = new FacebookUser("Adam", "christ");// third
																			// account
				FacebookUser account4 = new FacebookUser("Sarah", "jesus");// 4th
																			// account
				FacebookUser account5 = new FacebookUser("Eric", "mom");// 5th
																		// account

				
				Object[] UsersArray = {account1, account2, account3,account4, account5};
				for(int i =0; i<UsersArray.length; i++)
					System.out.print(UsersArray[i] +" ");
				System.out.println();
				System.out.println("\n Sorting test: Facebook Users");
				System.out.println("After Sorted");
				Random rnd11 = new Random();
			    for (int i = UsersArray.length - 1; i > 0; i--)
			    {
			      int index = rnd11.nextInt(i + 1);
			      // Simple swap
			      Object a = UsersArray[index];
			      UsersArray[index] = UsersArray[i];
			      UsersArray[i] = a;
			    

			}
				
				
				 break;

			
		
				
			
			case 4:
				System.exit(0);
			

				
				
			}

		}
	}
}