import java.util.Arrays;
import java.util.Comparator;

public class QuickSort{
	public static<E extends Comparable<E>>
	void quickSort(E[] list){
		quickSort(list, 0, list.length-1);
	}
	
	public static<E extends Comparable<E>>
	void quickSort(E[] list, int first, int last){
		 int size = (last-first+1);
	
		{
			int pivotIndex = partition(list, first, last);
			//recurissive
			quickSort(list, first, pivotIndex -1);
			quickSort(list,pivotIndex + 1, last);
			
		}

			
		}

	public static <E> void swap(E[] list, int dex1, int dex2) {
	    E temp = (E) list[dex1];
	    list[dex1] = list[dex2];
	    list[dex2] = temp;
	  }
	
	private static <E extends Comparable<E>>
	int partition(E[] list, int first, int last)
	{
		E pivot = list[first];
		//searching
		System.out.println("searching...");
		System.out.print(list);
		int low = first + 1;
		int high = last;
		while(high > low)
		{
			
			//searching foreword <---
			
			while(low <= high && list[low].compareTo(pivot)<= 0)
				low++;
			System.out.println("\t"+ list[low]+ " comparing to "+ pivot);//< =0
			//searching back
			System.out.println( "low:" + low+ " high: "+ high +
					" "+list[high]+ " comparing to "+ pivot +" ");//< =0
			while(low <= high && list[high].compareTo(pivot)>0)
				high--;
			
			//swaping i from the list
			if(high > low){
				
				E temp = list[high];
				
				list[high] = list [low];
				list[low] = temp;
			}
		}
		System.out.println("\t"+ high +" less than "+ first +","+ list[high]);//< =0
		while(high > first && list[high].compareTo(pivot)>=0)
			high--;
		//swap pivot with listhigh
		System.out.println("\t" + Arrays.toString(list));
		System.out.println("\t"+ pivot+ " comparing to "+ list[high]);//< =0
		if(pivot.compareTo(list[high])>0)
			
		{
			list[first] = list[high];
			list[high] = pivot;
			return high;
		}
		else{
			return first;
		}
	}
	
	
}
	