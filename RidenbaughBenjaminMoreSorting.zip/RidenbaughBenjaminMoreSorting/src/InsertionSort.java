import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;

public class InsertionSort {

	

	public static <E extends Comparable<E>> void Sort(E[] list) {

		boolean pass = true;
		

		for (int i = 1; i < list.length; i++) {
			

			System.out.println("pass: " + i);
			E base = list[i];
			System.out.println("\t" + Arrays.toString(list));
			int j;
			// System.out.println("\t"+ Arrays.toString(list)+ " comparing "+
			// list[i-1]);
			for (j = i - 1; j >= 0 && list[j].compareTo(base) > 0; j--) {// compares

				System.out.print("-swapping: "+ " index "+ j);
				list[j + 1] = list[j];
				System.out.println("");
				pass = true;
				// System.out.println("\n"+ list[j]);
			}// loop ends
			System.out.println("");
			list[j + 1] = base;
			

		}
		
		for (int j = 0; j <= list.length; j++) {
			System.out.println(list[j]);
			break;
		}
	
		}

		

	
	

	
}


