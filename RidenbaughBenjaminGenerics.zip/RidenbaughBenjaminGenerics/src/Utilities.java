import java.util.ArrayList;

public class Utilities {
	public static <E> ArrayList<E> removeDuplicates(ArrayList<E> list){
		for(int i = 0; i<list.size(); i++){
			for(int j = 0; j < list.size(); j++)
			{
				if( i == j){
					continue;
				}
					
			
			else if (list.get(i) == list.get(j)){
				list.remove(j);// removes the duplicates
			}
			}
			
		}
		return list;
		
	}
	
	// generic sort method
	public static <E extends Comparable<E>>
	void insertionSort(E[] list){
		for (int i = 1; i < list.length;i++){
			E base = list[i];
			int j;
			
			for(j = i -1;j >= 0 && list[j].compareTo(base) > 0; j--){//compares
				
				list[j +1] = list [j];
				
			}// loop ends
			list [j + 1] = base;
			
		}
		for(int j = 0; j < list.length; j++){ 
			System.out.print(list[j]+ "\n"); 
			}
		
	}
}
