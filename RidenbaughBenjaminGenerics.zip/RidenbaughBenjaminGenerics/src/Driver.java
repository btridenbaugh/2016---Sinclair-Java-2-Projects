import java.lang.*;
import java.util.*;
public class Driver {
	
	public static void main(String[] args)
	{
		Utilities ab = new Utilities();
		
		ArrayList<Integer> intList = new ArrayList<Integer>();
		// testing list integer
		
		intList.add(10);
		intList.add(10);
		intList.add(20);
		intList.add(30);
		intList.add(30);
		intList.add(40);
		
		//string list
		ArrayList<String> Stringlist = new ArrayList<String>();
		Stringlist.add("A");
		Stringlist.add("A");
		Stringlist.add("A");
		Stringlist.add("A");
		Stringlist.add("B");
		Stringlist.add("C");
		Stringlist.add("C");
		
		System.out.println("String List: ");
		for(int i = 0; i < Stringlist.size(); i++){
			System.out.print(Stringlist.get(i)+"\n");
		}
		ArrayList<String> newStringlist =  ab.removeDuplicates(Stringlist);
		
		System.out.println("\nString list with duplicates removed: ");
		for(int i=0; i < newStringlist.size(); i++){
			
			System.out.println(newStringlist.get(i));
		}
		
		System.out.println("Integer list: ");
		for(int i = 0; i < intList.size(); i++){
			System.out.print(intList.get(i)+"\n");
		}
		
		
		ArrayList<Integer> newlist =  ab.removeDuplicates(intList);
		
		System.out.println("\nInteger list with duplicates removed: ");
		for(int i=0; i < newlist.size(); i++){
			
			System.out.println(newlist.get(i));
		}
		
		System.out.println("\n Sorting test");
		
		Integer[] numbers = {30,0,10,20,70,60,90};
		
		System.out.println(numbers);
		System.out.println("After Sorting");
		Utilities.insertionSort(numbers);
		
		
	}
	
	
}
