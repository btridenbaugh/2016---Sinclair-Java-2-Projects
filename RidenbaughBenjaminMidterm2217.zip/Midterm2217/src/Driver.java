import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashSet;
import java.util.Scanner;




public class Driver {
	static HashSet<TwitterUser> users;
	static HashSet<Integer> userIDs;
	
	
	public static void main(String[] args) throws FileNotFoundException {
		users = new HashSet<TwitterUser>();
		userIDs = new HashSet<Integer>();
		
		File file = new File("C://Users/coolc/Downloads/social_network.edgelist/social_network.edgelist");
	Scanner sc = new Scanner (System.in);
	
	System.out.println("Please wait. Reading the file...");
	sc = new Scanner(file);
	int total=0;
	int i=0;
	int j=0;
	TwitterUser a = null, b = null;
	while (sc.hasNextLine()) {
		if (sc.hasNext())
		i = sc.nextInt();
		else
			break;
		if (userIDs.add(i)) {
			a = new TwitterUser(i);

			users.add(a);

		}
		j = sc.nextInt();
		
		if (userIDs.add(j)) {
			b = new TwitterUser(j);

			users.add(b);
		}
		a.addFollowing(b);

		total ++;
	}

	sc.close();
	System.out.println(total + " users have been added.");
	System.out.println("File has been read.");
	
		Scanner prompt = new Scanner(System.in);
		Scanner res = new Scanner(file);
		System.out.println("What user would you like to test?");
			int id = prompt.nextInt();
		System.out.println("What is the depth you would like to go in the neighbourhood?");
			int depth = prompt.nextInt();

			System.out.println("User " + id + " Followers: ");
			for (TwitterUser f :users){
				if (f.userID == id){
					HashSet<TwitterUser> gNeighbor = f.getNeighborhood(
							null, depth);
				}
					System.out.println(f.userID);

			}
			System.out.println("Now Cloning...");
			
			TwitterUser c = null,d = null;
			
			try {
				d = a.clone();
				d.addFollowing(c);
				System.out.println(a.userID);
				System.out.println(a.getFollower());
				System.out.println(d.userID);
				System.out.println(d.getFollower());
			} catch (CloneNotSupportedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			}
			
			
			
			
			

	
	
	}	
	
