
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;


@SuppressWarnings("rawtypes")
public class TwitterUser implements Comparable, Cloneable {
	
	int userID;
	
	
	public ArrayList<TwitterUser> following;
	
	
	public TwitterUser(int user){
		userID=user;

		following = new ArrayList<TwitterUser>();
	
	}	
	

	//ArrayList<TwitterUser> follower;
	public void addFollowing(TwitterUser newFollower){
		int i =  findFollowing(newFollower);
		if(i == -1){
			following.add(newFollower);
			
		}
		else 
			System.out.println(newFollower +" is already is following");
	}
	// user to un follow
	public void unFollowing(TwitterUser unFollower){
		int i = findFollowing(unFollower);
		if(i ==-1){
			System.out.println(unFollower +" not found");
		}
		else
		{
			following.remove(i);
		}
	}
	java.util.ArrayList<TwitterUser> getFollower(){
		return following;
	}
	
	


	private int findFollowing(TwitterUser ID) {
		if(following.isEmpty())
			
		// TODO Auto-generated method stub
		return -1;
		for(int i = 0; i <following.size(); i++){
			if(following.get(i).equals(following))
				return i;
			
		}
		return -1;
	}
	//deep cloning
	public TwitterUser clone() throws CloneNotSupportedException{
		TwitterUser Clone = new TwitterUser( userID);
		Clone.following = new ArrayList<TwitterUser>(this.following.size());
		for(int i =0; i< following.size();i++)
			Clone.following.add(i, this.following.get(i).clone());
		
		return Clone;
	}
	@SuppressWarnings("unchecked")
	public HashSet<TwitterUser> getNeighborhood(HashSet<TwitterUser> fList, int depth) {
		//fList is null First time
		// not null when recursion; fList is set that has to be excluded from set of following during recursion
		HashSet<TwitterUser> gList = new HashSet<TwitterUser>(following);
		//Case Recursion: Returns all following except those in fList
		// for recursion Friend of following not required since we stop when there is no more possible following limit checkis done 
		if(fList != null){		
			gList.removeAll(fList); 
			return gList;
			
		}
		// case not recursion
		
		
		if (gList.isEmpty())
			return gList;// no recommendation
		// second
		
		HashSet<TwitterUser> g = new HashSet<TwitterUser>();

		for (TwitterUser f : gList) g.addAll(f.following);
		gList.add(this);
		
		g.removeAll(gList);
		
		if (g.isEmpty())
			return g;
		// now we have set of following of following
				// but we don't know if we have all possible new following
				// so we have to go over this list again and again till the size does
				// not get changed
				// h grows while we iterate on g
		// Third - following of following union to any level of Recursive depth -
		// this needs an extra iteration recognize the end that limit is reached
		// there shall not be anymore possible following
		int prev = g.size();
		HashSet<TwitterUser> h = (HashSet<TwitterUser>) g.clone();
		
		while (true) {
			
		//gList is set of following and user the Set returned after recursion must not include gList set
			depth--;
			if(depth<=0) return g;
			for (TwitterUser f : g){
				h.addAll(f.getNeighborhood(gList,depth));
			}
			h.removeAll(gList); // ist level friend must always be removed
			if (prev < h.size()) {

				prev = h.size();
				g = (HashSet<TwitterUser>) h.clone();
			} else 
				return g; // recommendation
		}
	}
		
    

	public int compareTo(Object o) {
		// TODO Auto-generated method stub
		
		return this.userID - ((TwitterUser)o).userID;
	}



}
