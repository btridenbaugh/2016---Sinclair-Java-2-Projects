import java.util.ArrayList;

public class FacebookUser extends UserAccount implements
		Comparable<FacebookUser> {
	public FacebookUser(String username, String password) {
		super(username, password);
		friends = new ArrayList<FacebookUser>();
	}

	String passwordHint;
	ArrayList<FacebookUser> friends;

	void setPasswordHint(String hint) {
		passwordHint = hint; // hint
	};

	void friend(FacebookUser newFriend) {
		friends.add(newFriend); // adding friends
	};

	void defriend(FacebookUser formerFriend) { //  defriending
		friends.remove(formerFriend);
	};

	ArrayList<FacebookUser> getFriends() {
		return friends;
	};

	public void getPasswordHelp() {
		System.out.println(passwordHint);

	};

	@Override
	public int compareTo(FacebookUser o) {
		return username.toString().toLowerCase().compareTo(o.username.toLowerCase());// ignore case
 		
	}

}
