import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


public class AccountDriver {


	
	

	public static void main(String [] args){
		
		FacebookUser account1 = new FacebookUser("Ben", "pass1");// new account object
		FacebookUser account2 = new FacebookUser("Kendall", "pass2");// second account object
		FacebookUser account3 = new FacebookUser("Danny", "pass3");// third account
		FacebookUser account4 = new FacebookUser("Hannah", "pass4");// 4th account
		FacebookUser account5 = new FacebookUser("Ray", "pass5");// 5th account
		
		List<FacebookUser> users = new ArrayList<FacebookUser>();
		
		users.add(account1);// adding 
		users.add(account2);
		users.add(account3);
		users.add(account4);
		users.add(account5);
		
		account1.setPasswordHint("pass hint");// hint for account1
		account1.friend(account2);// adding friend
		System.out.println(account1.getFriends());
		account1.defriend(account2);// defriending account2
		
		System.out.println(account1.getFriends());
		account1.getPasswordHelp();
		
	 
		
		//System.out.println("account1:\n" +account1);
		//System.out.println("account2:\n" +account2);
		
		System.out.println(users);//before sorting
		
		
		Collections.sort(users);// sorted users
		
	
        System.out.println(users);
		
		
		
	}
}
