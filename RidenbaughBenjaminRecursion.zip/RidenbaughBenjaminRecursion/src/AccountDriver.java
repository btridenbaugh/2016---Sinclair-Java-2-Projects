import java.awt.List;
import java.util.HashSet;
import java.util.Scanner;

public class AccountDriver {
	static Facebook ab;

	public static int getMenuOption() {

		// Facebook ab = new Facebook();

		System.out.print("\nMenu \n1. List Users" + "\n2. Add a User"
				+ "\n3. Delete a User" + "\n4. Get password hint"
				+ "\n5. Add a friend" + "\n6. Remove a friend"
				+ "\n7. List friends" + "\n8. Recommend friends" + "\n9. Quit");

		System.out.print("\nWhat would you like to do: ");
		@SuppressWarnings("resource")
		Scanner input1 = new Scanner(System.in);
		int num4 = input1.nextInt();

		while ((num4 < 1 || num4 > 9) && num4 != 9)// added this to prompt the
													// inputs to user
		{
			System.out
					.println("Please the enter the options from above menu: ");
			num4 = input1.nextInt();
		}
		return num4;
	}

	public static void main(String[] args) {

		@SuppressWarnings("resource")
		Scanner input = new Scanner(System.in);
		// Get from user input that if this is virgin attempt to use this
		// application
		// in that case Facebook will be initialized with its user DB;else it
		// shall use the existing user DB

		System.out.println("Is it you first attempt (y/n): ");
		String ans = input.next();
		try {
			if (ans.toLowerCase().equals("y")) {

				ab = new Facebook("users.txt", true);

			} else {

				ab = new Facebook("users.txt", false);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		while (true) {

			int menu = getMenuOption();// menu

			String aName, aPassword;
			String aPasswordHint;

			// new user account
			switch (menu) {
			case 1:
				// list of users

				if (ab.users.isEmpty()) {// checks the list
					System.out.println("No users have been entered yet");
					System.out.print(System.getProperty("line.separator"));
				} else
					System.out.println(ab.users);

				break;

			case 2: // add
				FacebookUser fUser;
				while (true) {
					System.out.println("Please enter an Username: ");

					aName = input.next();
					if (ab.findUser(aName) == -1)
						break;
				}

				System.out.println("Enter a password: ");
				aPassword = input.next();

				fUser = new FacebookUser(aName, aPassword);

				System.out.println("Enter a password hint: ");// enter hint
				aPasswordHint = input.next();
				fUser.setPasswordHint(aPasswordHint);

				ab.addUsers(fUser);
				break;

			case 3: // delete a user

				System.out.println("Please enter an Username: ");

				aName = input.next();

				ab.deleteUser(aName);
				break;
			case 4: // show password hint

				System.out.println("Please enter an Username: ");

				aName = input.next();
				ab.getPasswordHint(aName);

				break;

			// adding a friend and Option 5

			case 5:

				// while (true) {
				System.out.println("Iamin Add User ");
				System.out.println("Please enter an Username: ");
				aName = input.next();
				int i,
				j;
				if ((i = ab.findUser(aName)) == -1) {
					// message user not found
					System.out.println(aName + " not found");
					break;
				} else {

					System.out.println("Password: ");// get the password for the
														// username
					aPassword = input.next();
					if (!ab.users.get(i).getPassword().equals(aPassword)) { // checks
																			// the
																			// password
						
						// message
						System.out.println("Wrong password");
						break;
					}

					System.out.println("Please enter the friend's username: ");// enters
																				// the
																				// username
					aName = input.next();
					if ((j = ab.findUser(aName)) == -1) {
						// message user not found

						System.out.println(aName + " not found");

						break;
					}
				}

				ab.users.get(i).addFriend(ab.users.get(j));
				
				ab.users.get(j).addFriend(ab.users.get(i));
				// ab.users.get(i).friends.add(ab.users.get(j));
				break;

			case 6:
				System.out.println("Please enter an Username: ");
				aName = input.next();
				if ((i = ab.findUser(aName)) == -1) {
					// message
					System.out.println(aName + " not found");
					break;
				} else {
					System.out.println("Password: ");// get the password for the
														// username
					aPassword = input.next();
					if (!ab.users.get(i).getPassword().equals(aPassword)) {
						;
						// message
						System.out.println("Wrong password");
						break;
					}
					System.out.println("Please enter the friend's username: ");
					aName = input.next();
					if ((j = ab.findUser(aName)) == -1) {
						System.out.println(aName + " not in the friend list");
						break;
					}
				}

				ab.users.get(i).deFriend(ab.users.get(j));
				ab.users.get(j).deFriend(ab.users.get(i));
				break;

			// list all friends of user
			case 7:
				System.out.println("Please enter an Username: ");
				aName = input.next();
				if ((i = ab.findUser(aName)) == -1) {
					System.out.println(aName + " not found");
					break;
				} else {
					if (ab.users.get(i).getFriends().isEmpty()) {
						System.out.println("User has no friends");
					} else {
						System.out.println(ab.users.get(i).getFriends());
					}
				}
				break;

			// get friends recommendation who are not your friends
			case 8:
				System.out.println("Please enter an Username: ");
				aName = input.next();
				if ((i = ab.findUser(aName)) == -1) {
					System.out.println(aName + " not found");
					break;
				} else {
					HashSet<FacebookUser> gFriend = ab.users.get(i).getRecommendation(null);
					if (gFriend.isEmpty()) {
						System.out.println("No new friend found");
					} else {
						System.out.println("recomended"+gFriend);
					}
				}
				break;

			case 9:
				System.out.println("Goodbye");
				try {
					ab.serialize();
				} catch (Exception e) {
					e.printStackTrace();
				}
				System.exit(0);

			}
		}
	}
}
