import java.io.*;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Scanner;

import javax.swing.JOptionPane;

public class FacebookUser extends UserAccount implements Serializable,
		Comparable<FacebookUser> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static Scanner input = new Scanner(System.in);

	public FacebookUser(String username, String password) {
		super(username, password);
		friends = new ArrayList<FacebookUser>();
	}

	String passwordHint;
	ArrayList<FacebookUser> friends;

	void setPasswordHint(String hint) {
		passwordHint = hint; // hint
	};


	// adding a new friend, and FacebookUser
	public void addFriend(FacebookUser newFriend) {
	
		int i = findFriend(newFriend.username);
		if (i == -1){
			friends.add(newFriend);
			
			
		}
		else
			System.out.println(newFriend.username + " is already a friend");

	}

	// defriending a friend
	public void deFriend(FacebookUser formerFriend) {

		int i = findFriend(formerFriend.username);
		if (i == -1)
		{
			System.out.println(formerFriend.username + " is not found");

		}
		else
			{friends.remove(i);
			
			}

	}

	// displays users that are friends of friends

	@SuppressWarnings("unchecked")
	public HashSet<FacebookUser> getRecommendation(HashSet<FacebookUser> fList) {
		//fList is null First time

		HashSet<FacebookUser> gList = new HashSet<FacebookUser>(friends);
		//Case Recursion: Returns all Friends except those in fList

		if(fList != null){		
			gList.removeAll(fList); 
			return gList;
			
		}
		// case not recursion
		
		
		if (gList.isEmpty())
			return gList;// no recommendation
		// second
		
		HashSet<FacebookUser> g = new HashSet<FacebookUser>();

		for (FacebookUser f : gList) g.addAll(f.friends);
		gList.add(this);
		
		g.removeAll(gList);
		
		if (g.isEmpty())
			return g;
		// now we have set of friends of friends, but it may not be the maximum
		int prev = g.size();
		HashSet<FacebookUser> h = (HashSet<FacebookUser>) g.clone();
		
		while (true) {
			
		//gList is set of friends and user the Set returned after recursion must not include gList set
			for (FacebookUser f : g){
				System.out.println("recursing"+f);
				h.addAll(f.getRecommendation(gList));
			}
			h.removeAll(gList); // list level friend must always be removed
			if (prev < h.size()) {

				prev = h.size();
				g = (HashSet<FacebookUser>) h.clone();
			} else 
				return g; // recommendation
		}
	}
		
	// findFriend finds friend, and defriends if currently a friend, or friends if not

	public int findFriend(String name) {
		if (friends.isEmpty())
			return -1;// s
		for (int i = 0; i < friends.size(); i++) {
			if (friends.get(i).username.equals(name))
				return i;
		}
		return -1;

	}


	ArrayList<FacebookUser> getFriends() {

		return friends;
	};

	public void getPasswordHelp() {
		JOptionPane.showMessageDialog(null, passwordHint);

	};

	public String getUsername() {
		return username;
	}

	public String getPassword() {
		return password;
	}

	@Override
	public int compareTo(FacebookUser o) {
		return username.toString().toLowerCase()
				.compareTo(o.username.toLowerCase());// case ignore

	}

}
