import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Facebook implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	List<FacebookUser> users = new ArrayList<FacebookUser>();
	String fileN, username, password;


	public Facebook(String fileName, boolean empty) {
		fileN = fileName;

		if (!empty)
			deserialize();// deserialized

	}

	public void listAll() {
		System.out.println(users);
	}

	public void addUsers(FacebookUser user) {
		users.add(user);
	}

	public void deleteUser(String userN) {
		int i = findUser(userN);
		if (i == -1)
			System.out.println(userN + " not found");
		else
			users.remove(i);

	}
	
	// given a user name uses the users list to find the user returns its index
	public int findUser(String name) {
		if (users.isEmpty())
			return -1;//
		for (int i = 0; i < users.size(); i++) {
			if (users.get(i).username.equals(name))
				return i;
		}
		return -1;

	}
	
	//Find password of a user
	

	// print the password hint
	public void getPasswordHint(String userN) {
		int i = findUser(userN);
		if (i == -1)
			System.out.println(userN + " not found");
		else
			System.out.println(users.get(i).passwordHint);
	}
	//EXPLANATION:We are supposed to use the SET dataStructure because we are not allowing duplicates
	//It uses the equals method to make sure that two objects are not Identical 

	public void serialize() throws IOException {
		ObjectOutputStream output = new ObjectOutputStream(
				new FileOutputStream(fileN));

		output.writeObject(users);
		output.flush();
		output.close();
	}

	@SuppressWarnings("unchecked")
	public void deserialize() {

		ObjectInputStream input = null;
		try {
			input = new ObjectInputStream(new FileInputStream(fileN));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.exit(-2);
		}

		try {
			//users = new ArrayList<FacebookUser>();
			users = (List<FacebookUser>) input.readObject();
			input.close();
		} catch (ClassNotFoundException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.exit(-1);
		}

	}
}
