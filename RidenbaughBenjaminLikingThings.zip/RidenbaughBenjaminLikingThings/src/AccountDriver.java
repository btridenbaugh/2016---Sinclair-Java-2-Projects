import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;

public class AccountDriver {
	static Facebook ab, ab2;

	public static int getMenuOption() {

		System.out.print("\nMenu \n1. List Users alphabetically"
				+ "\n2. List users by number of friends" + "\n3. Add a User"
				+ "\n4. Delete a User" + "\n5. Get password hint"
				+ "\n6. Add a friend" + "\n7. Remove a friend"
				+ "\n8. List friends" + "\n9. Recommend friends" + "\n10. Like"
				+ "\n11. Sorted Like List" + "\n12. Quit");

		System.out.print("\nWhat would you like to do: ");
		@SuppressWarnings("resource")
		Scanner input1 = new Scanner(System.in);
		int num4 = input1.nextInt();

		while ((num4 < 1 || num4 > 12) && num4 != 12)// added this to prompt the
														// inputs to user
		{
			System.out
					.println("Please the enter the options from above menu: ");
			num4 = input1.nextInt();
		}
		return num4;
	}

	public static void main(String[] args) {

		@SuppressWarnings("resource")
		Scanner input = new Scanner(System.in);
		// Get from user input that if this is first attempt to use this
		// application
		// in that case Facebook will be initialized with its user DB

		System.out.println("Is it you first attempt (y/n): ");
		String ans = input.next();
		try {
			if (ans.toLowerCase().equals("y")) {

				ab = new Facebook("users.txt", true);

			} else {

				ab = new Facebook("users.txt", false);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		while (true) {

			int menu = getMenuOption();// menu

			String aName, aPassword;
			String aPasswordHint;

			// new user account
			switch (menu) {
			case 1:
				// list of users

				if (ab.users.isEmpty()) {// checks the list
					System.out.println("No users have been entered yet");
					System.out.print(System.getProperty("line.separator"));

					break;
				} else
					// collection is sorted
					Collections.sort(ab.users);
				System.out.println(ab.users);

				break;
			// list users with their friend list size
			case 2:
				Collections.sort(ab.users, new FriendListSize());
				Object userSize;
				for (FacebookUser UserSize : ab.users) {
					System.out.println(UserSize);
				}
				
				break;

			case 3: // add
				FacebookUser fUser;
				while (true) {
					System.out.println("Please enter an Username: ");

					aName = input.next();
					if (ab.findUser(aName) == -1)
						break;
				}

				System.out.println("Enter a password: ");
				aPassword = input.next();

				fUser = new FacebookUser(aName, aPassword);

				System.out.println("Enter a password hint: ");// enter hint
				aPasswordHint = input.next();
				fUser.setPasswordHint(aPasswordHint);

				ab.addUsers(fUser);
				break;

			case 4: // delete a user

				System.out.println("Please enter an Username: ");

				aName = input.next();

				ab.deleteUser(aName);
				break;
			case 5: // show password hint

				System.out.println("Please enter an Username: ");

				aName = input.next();
				ab.getPasswordHint(aName);

				break;

			// adding a friend and Option 6

			case 6:

				// while (true) {
				System.out.println("I am in Add User ");
				System.out.println("Please enter an Username: ");
				aName = input.next();
				int i,
				j;
				if ((i = ab.findUser(aName)) == -1) {
					// message user not found
					System.out.println(aName + " not found");
					break;
				} else {

					System.out.println("Password: ");// get the password for the
														// username
					aPassword = input.next();
					if (!ab.users.get(i).getPassword().equals(aPassword)) { // checks
																			// the
																			// password

						// message
						System.out.println("Wrong password");
						break;
					}

					System.out.println("Please enter the friend's username: ");// enters
																				// the
																				// username
					aName = input.next();
					if ((j = ab.findUser(aName)) == -1) {
						// message user not found

						System.out.println(aName + " not found");

						break;
					}
				}

				ab.users.get(i).addFriend(ab.users.get(j));

				ab.users.get(j).addFriend(ab.users.get(i));
			
				break;

			case 7:
				System.out.println("Please enter an Username: ");
				aName = input.next();
				if ((i = ab.findUser(aName)) == -1) {
					// message
					System.out.println(aName + " not found");
					break;
				} else {
					System.out.println("Password: ");// get the password for the
														// username
					aPassword = input.next();
					if (!ab.users.get(i).getPassword().equals(aPassword)) {
						;
						// message
						System.out.println("Wrong password");
						break;
					}
					System.out.println("Please enter the friend's username: ");
					aName = input.next();
					if ((j = ab.findUser(aName)) == -1) {
						System.out.println(aName + " not in the friend list");
						break;
					}
				}

				ab.users.get(i).deFriend(ab.users.get(j));
				break;

			// list all friends of user
			case 8:
				int k;
				System.out.println("Please enter an Username: ");
				aName = input.next();
				if ((k = ab.findUser(aName)) == -1) {
					System.out.println(aName + " not found");
					break;
				} else {
					if (ab.users.get(k).getFriends().isEmpty()) {
						System.out.println("User has no friends");
					} else {
						System.out.println(ab.users.get(k).getFriends());
					}
				}
				break;

			// get friends recommendation who are not your friends
			case 9:
				System.out.println("Please enter an Username: ");
				aName = input.next();
				if ((i = ab.findUser(aName)) == -1) {
					System.out.println(aName + " not found");
					break;
				} else {
					HashSet<FacebookUser> gFriend = ab.users.get(i)
							.getRecommendation(null);
					if (gFriend.isEmpty()) {
						System.out.println("No new friend found");
					} else {
						System.out.println("recomended" + gFriend);
					}
				}
				break;
			case 10:
				//EXPLANATION:We are supposed to use the HashSet dataStructure because we are not allowing duplicates
				//It uses the equals method to make sure that two objects are not Identical 

				System.out.println("Please enter an Username: ");
				aName = input.next();
				int p;
				if ((p = ab.findUser(aName)) == -1) {
					// message
					System.out.println(aName + " not found");
					break;
				} else {
					System.out.println("Password: ");// get the password for the
														// username
					aPassword = input.next();
					if (!ab.users.get(p).getPassword().equals(aPassword)) {

						// message
						System.out.println("Wrong password");
						break;
					}

					System.out.println("do you like (y/n)? ");// y for yes and "n" for dislike option
					String ans1 = input.next();
					if (ans1.equals("y")) {
						System.out.println("What do you like? ");

						String getLike = input.next();

						ab.users.get(p).likes.add(getLike);
						System.out.println(aName+" likes "+ getLike);
						break;
					}
					else {
						System.out.println(ab.users.get(p).likes);
						System.out
								.println("What would you like to remove from the list: ");
						String dislike = input.next();
						if(ab.users.get(p).likes.contains(dislike)){
						ab.users.get(p).likes.remove(dislike);

					}
						else{
							System.out.println(dislike + " is not in the list");
						}

				}
				}

				break;

			case 11:
				System.out.println("Please enter an Username: ");
				aName = input.next();
				
				if ((p = ab.findUser(aName)) == -1) {
					// message
					System.out.println(aName + " not found");
					break;
				} 
				
				Set orderedLikes = new TreeSet<String>(ab.users.get(p).likes);
					
					System.out.println(aName + " likes " + ab.users.get(p).likes.size()+" things");
					System.out.println(orderedLikes);
				


				break;
			case 12:
				System.out.println("Goodbye");
				try {
					ab.serialize();
				} catch (Exception e) {
					e.printStackTrace();
				}
				System.exit(0);

			}
		}
	}
}
