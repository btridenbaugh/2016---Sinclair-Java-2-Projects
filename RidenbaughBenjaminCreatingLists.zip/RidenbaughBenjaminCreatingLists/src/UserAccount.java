import java.io.Serializable;


public abstract class UserAccount implements Serializable {// serializeration
	protected String username; // userAccount
	protected String password;// private data type password
	protected boolean active = true; // indicates the account active

	public UserAccount(String user, String pass) {
		username = user;
		password = pass;
	}

	public boolean checkPassword(String psw) {
		if (password.equals(psw))return true;
		else return false;
	}

	public void deactivateAccount() {
		active = false;// make the account deactive

	}
	
	
	@Override
	public String toString() {
		//hiding password from display
		return "UserAccount [username=" + username + ", password=" + "*******"
				+ ", active=" + active + ", toString()=" + super.toString()
				+ "]";//password is hidden
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (active ? 1231 : 1237);
		result = prime * result
				+ ((password == null) ? 0 : password.hashCode());
		result = prime * result
				+ ((username == null) ? 0 : username.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		UserAccount other = (UserAccount) obj;
		if (active != other.active)
			return false;
		if (password == null) {
			if (other.password != null)
				return false;
		} else if (!password.equals(other.password))
			return false;
		if (username == null) {
			if (other.username != null)
				return false;
		} else if (!username.equals(other.username))
			return false;
		return true;
	}
	
	
public abstract void getPasswordHelp();

	
}
